//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PowerMate_HID.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_POWERMATE_HID_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_SLIDER_BRIGHTNESS           1000
#define IDC_BUTTON_GET_BRIGHTNESS       1001
#define IDC_BUTTON_GET_PULSE_ALWAYS     1002
#define IDC_BUTTON_GET_PULSE_DURING_SLEEP 1003
#define IDC_BUTTON_GET_PULSE_SPEED      1005
#define IDC_EDIT_BRIGHTNESS             1006
#define IDC_EDIT_PULSE_ALWAYS           1007
#define IDC_EDIT_PULSE_DURING_SLEEP     1009
#define IDC_EDIT_LED_CONTROL            1010
#define IDC_EDIT_PULSE_SPEED            1012
#define IDC_BUTTON_PULSE_ALWAYS_ON      1015
#define IDC_BUTTON_PULSE_ALWAYS_OFF     1016
#define IDC_BUTTON_PULSE_DURING_SLEEP_ON 1017
#define IDC_BUTTON_LOW_POWER_MODE       1018
#define IDC_SLIDER_PULSE_SPEED          1023
#define IDC_EDIT_AXIS_DATA              1024
#define IDC_EDIT_BUTTON_DATA            1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
