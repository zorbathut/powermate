// PowerMateThread.cpp : implementation file
//

#include "stdafx.h"
#include "PowerMate_HID.h"
#include "PowerMateThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPowerMateThread

IMPLEMENT_DYNAMIC(CPowerMateThread, CWinThread)

CPowerMateThread::CPowerMateThread(CPowerMateDlg *pWnd)
{
	m_pDlgWnd = pWnd;
	m_hPowerMate = m_pDlgWnd->m_hReadHandle;
}

CPowerMateThread::~CPowerMateThread()
{
}

BOOL CPowerMateThread::InitInstance()
{
	char reportBuffer[8];
	DWORD txdBytes;
	BOOL result;

	m_OldButtonState = 0;
	m_pDlgWnd->m_AxisDataEditCtrl.SetWindowText("0");
	m_pDlgWnd->m_ButtonDataEditCtrl.SetWindowText("Up");
	m_Running = TRUE;
	while (m_Running == TRUE)
	{
		result = ReadFile(m_hPowerMate, reportBuffer, sizeof(reportBuffer), &txdBytes, NULL);
		if (result)
		{
			if( txdBytes == 7)
				PerformAction(m_hPowerMate, reportBuffer);
		}
		else
			break;
	}

	AfxEndThread(0);
	
	// avoid entering standard message loop by returning FALSE
	return FALSE;
}

int CPowerMateThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CPowerMateThread, CWinThread)
	//{{AFX_MSG_MAP(CPowerMateThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPowerMateThread message handlers


void CPowerMateThread::PerformAction(HANDLE hPowerMate, char *reportBuffer)
{
	CString editText;
	char	num[6];

	// get button state
	if (reportBuffer[1] == 1 && m_OldButtonState == 0)
	{
		// detected a button down
		m_pDlgWnd->m_ButtonDataEditCtrl.SetWindowText("Down");
		m_OldButtonState = 1;
	}
	else if (reportBuffer[1] == 0 && m_OldButtonState == 1)
	{
		// detected a button up
		m_pDlgWnd->m_ButtonDataEditCtrl.SetWindowText("Up");
		m_OldButtonState = 0;
	}
	// get knob displacement
	if (reportBuffer[2] > 0)
	{
		// knob data is positive, do the right turn action
		editText.Format("%d", reportBuffer[2]);
		m_pDlgWnd->m_AxisDataEditCtrl.SetWindowText(editText);
	}
	else if (reportBuffer[2] < 0)
	{
		// negative knob data, do the left turn action
		editText.Format("%d", reportBuffer[2]);
		m_pDlgWnd->m_AxisDataEditCtrl.SetWindowText(editText);
	}

	sprintf(num, "%d", (unsigned char)reportBuffer[4]);	
	m_pDlgWnd->m_GetBrightnessEditCtrl.SetWindowText(num);

	
	if (reportBuffer[5] & 0x01)
		m_pDlgWnd->m_PulseAlwaysEditCtrl.SetWindowText("ON");
	else
		m_pDlgWnd->m_PulseAlwaysEditCtrl.SetWindowText("OFF");
		
	if (reportBuffer[5] & 0x04)
		m_pDlgWnd->m_PulseDuringSleepEditCtrl.SetWindowText("Pulse During Sleep");
	else
		m_pDlgWnd->m_PulseDuringSleepEditCtrl.SetWindowText("Low Power Mode");

	int pulseSpeed = (reportBuffer[5] & 0x30) << 4;
	int pulseTable = (reportBuffer[5] & 0xC0) << 6;
	sprintf(num, "%d", (unsigned char)reportBuffer[6]);	
	m_pDlgWnd->m_PulsingSpeedEditCtrl.SetWindowText(num);
}
